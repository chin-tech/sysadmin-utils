#!/usr/bin/env bash

ref="/var/lib/laps"

mkdir -p $(dirname "$ref")


function runLaps {
   echo "Doing work..."
}

function updateRef {
   local r=$1
   next_date=$(date '+%Y-%m-01' -d '+1 month')
   touch -d "$next_date" "$r"
}

function checkTime {
   local r=$1
   now=($date "+%s")
   next_run=$()
}

now=$(date +%s)

if [[ ! -e $ref ]]; then
   touch $ref
   touch -d "now" "$ref"
   runLaps
   updateRef $ref
   exit
fi



